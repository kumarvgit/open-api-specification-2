import connexion
import six

from swagger_server.models.beer import Beer  # noqa: E501
from swagger_server.models.beer_paged_list import BeerPagedList  # noqa: E501
from swagger_server import util


def delete_beer_by_id_v1(beer_id):  # noqa: E501
    """Delete a beer by its id

    Delete beer by id # noqa: E501

    :param beer_id: beer id to be found
    :type beer_id: 

    :rtype: None
    """
    return 'do some magic!'


def get_all_beers_v1(page_number=None, page_size=None):  # noqa: E501
    """Get all beers in system

    Find all beers in system # noqa: E501

    :param page_number: Page number to be fetched
    :type page_number: int
    :param page_size: Number of records to be fetched
    :type page_size: int

    :rtype: BeerPagedList
    """
    return 'do some magic!'


def get_beer_by_id_v1(beer_id):  # noqa: E501
    """Get details of specified beer

    Get details of single **beer** # noqa: E501

    :param beer_id: beer id to be found
    :type beer_id: 

    :rtype: Beer
    """
    return 'do some magic!'


def post_beers_v1(body):  # noqa: E501
    """created a new beer

    creats a new beer # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Beer.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'


def update_beer_by_id_v1(beer_id, body=None):  # noqa: E501
    """Update beer

    Update beer # noqa: E501

    :param beer_id: beer id to be found
    :type beer_id: 
    :param body: 
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Beer.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
