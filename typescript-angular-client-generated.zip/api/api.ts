export * from './beers.service';
import { BeersService } from './beers.service';
export * from './customers.service';
import { CustomersService } from './customers.service';
export * from './orderService.service';
import { OrderServiceService } from './orderService.service';
export const APIS = [BeersService, CustomersService, OrderServiceService];
